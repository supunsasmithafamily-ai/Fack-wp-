import { useCallback, useEffect, useRef, useState } from 'react';
import { Message, MessageType } from '../types';
import { isFirebaseConfigured, uploadMediaAsync } from '../lib/firebase';
import {
  addMessageRemote,
  clearMessagesRemote,
  deleteMessageRemote,
  saveMessage,
  seedMessages,
  subscribeToMessages,
  updateMessageRemote,
} from '../services/firebaseChat';

const initialMessages: Message[] = [
  {
    id: 1,
    side: 'recv',
    senderName: 'Customer',
    text: 'Hi! I saw your new products. Looks great!',
    time: '09:01',
    type: 'text',
  },
  {
    id: 2,
    side: 'sent',
    senderName: 'You',
    text: 'Thank you! Would you like to know the price?',
    time: '09:02',
    type: 'text',
  },
];

const createId = () => Date.now() + Math.floor(Math.random() * 1000);
const currentTime = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

export function useMessages() {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [firebaseError, setFirebaseError] = useState<string | null>(null);
  const loadedRemoteData = useRef(false);

  useEffect(() => {
    if (!isFirebaseConfigured) return;

    const unsubscribe = subscribeToMessages(
      remoteMessages => {
        loadedRemoteData.current = true;
        if (remoteMessages.length === 0) {
          setMessages(initialMessages);
          void seedMessages(initialMessages).catch(error => setFirebaseError(error.message));
        } else {
          setMessages(remoteMessages);
        }
      },
      error => setFirebaseError(error.message),
    );

    return () => unsubscribe?.();
  }, []);

  const add = useCallback((message: Message) => {
    setMessages(previous => [...previous, message]);
    void addMessageRemote(message).catch(error => setFirebaseError(error.message));
  }, []);

  const addMessage = useCallback((
    text: string,
    side: 'sent' | 'recv',
    senderName: string,
    customTime?: string,
    type: MessageType = 'text',
    imageUri?: string,
    voiceDuration?: number,
  ) => {
    add({
      id: createId(),
      side,
      senderName: senderName.trim() || (side === 'recv' ? 'Customer' : 'You'),
      text: text.trim(),
      time: customTime || currentTime(),
      type,
      imageUri,
      voiceDuration,
    });
  }, [add]);

  const addImageMessage = useCallback(async (
    imageUri: string,
    side: 'sent' | 'recv',
    senderName: string,
    caption?: string,
    customTime?: string,
  ) => {
    const id = createId();
    let storedImageUri = imageUri;
    if (isFirebaseConfigured && !imageUri.startsWith('http')) {
      try {
        const extension = imageUri.split('.').pop()?.split('?')[0] || 'jpg';
        storedImageUri = await uploadMediaAsync(imageUri, `chats/demo-chat/media/${id}.${extension}`);
      } catch (error) {
        setFirebaseError(error instanceof Error ? error.message : 'Image upload failed');
      }
    }

    add({
      id,
      side,
      senderName: senderName.trim() || (side === 'recv' ? 'Customer' : 'You'),
      text: caption || '',
      time: customTime || currentTime(),
      type: 'image',
      imageUri: storedImageUri,
    });
  }, [add]);

  const addVoiceMessage = useCallback((
    duration: number,
    side: 'sent' | 'recv',
    senderName: string,
    customTime?: string,
  ) => {
    add({
      id: createId(),
      side,
      senderName: senderName.trim() || (side === 'recv' ? 'Customer' : 'You'),
      text: '',
      time: customTime || currentTime(),
      type: 'voice',
      voiceDuration: duration,
    });
  }, [add]);

  const addCallMessage = useCallback((
    callType: 'voice' | 'video',
    callStatus: 'missed' | 'answered' | 'outgoing',
    callDuration: number,
    side: 'sent' | 'recv',
    customTime?: string,
  ) => {
    add({
      id: createId(), side, senderName: '', text: '', time: customTime || currentTime(),
      type: 'call', callType, callStatus, callDuration,
    });
  }, [add]);

  const toggleMessageSide = useCallback((id: number) => {
    setMessages(previous => previous.map(message => {
      if (message.id !== id) return message;
      const updated = { ...message, side: message.side === 'sent' ? 'recv' as const : 'sent' as const };
      void updateMessageRemote(id, { side: updated.side }).catch(error => setFirebaseError(error.message));
      return updated;
    }));
  }, []);

  const updateMessageTime = useCallback((id: number, time: string) => {
    setMessages(previous => previous.map(message => message.id === id ? { ...message, time } : message));
    void updateMessageRemote(id, { time }).catch(error => setFirebaseError(error.message));
  }, []);

  const updateMessageSender = useCallback((id: number, senderName: string) => {
    setMessages(previous => previous.map(message => message.id === id ? { ...message, senderName } : message));
    void updateMessageRemote(id, { senderName }).catch(error => setFirebaseError(error.message));
  }, []);

  const deleteMessage = useCallback((id: number) => {
    setMessages(previous => previous.filter(message => message.id !== id));
    void deleteMessageRemote(id).catch(error => setFirebaseError(error.message));
  }, []);

  const clearMessages = useCallback(() => {
    setMessages(previous => {
      void clearMessagesRemote(previous).catch(error => setFirebaseError(error.message));
      return [];
    });
  }, []);

  return {
    messages,
    addMessage,
    addImageMessage,
    addVoiceMessage,
    addCallMessage,
    toggleMessageSide,
    updateMessageTime,
    updateMessageSender,
    deleteMessage,
    clearMessages,
    firebaseConnected: isFirebaseConfigured && !firebaseError,
    firebaseError,
    remoteDataLoaded: loadedRemoteData.current,
  };
}
