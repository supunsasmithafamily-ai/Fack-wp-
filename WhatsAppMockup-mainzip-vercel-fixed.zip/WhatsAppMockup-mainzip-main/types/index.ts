export type MessageType = 'text' | 'image' | 'voice' | 'call';

export interface Message {
  id: number;
  side: 'sent' | 'recv';
  senderName: string;
  text: string;
  time: string;
  type: MessageType;
  imageUri?: string;
  voiceDuration?: number;
  callType?: 'voice' | 'video';
  callDuration?: number;
  callStatus?: 'missed' | 'answered' | 'outgoing';
}

export interface Profile {
  name: string;
  number: string;
  img: string | null;
}

export type ThemeMode = 'light' | 'dark';
