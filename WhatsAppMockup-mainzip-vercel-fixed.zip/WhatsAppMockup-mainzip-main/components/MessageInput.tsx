import React, { useState, useRef } from 'react';
import { View, TextInput, StyleSheet, TouchableOpacity, Animated, Modal, Text, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { ThemeMode, MessageType } from '../types';
import { Colors, Typography, Spacing, BorderRadius } from '../constants/theme';

interface MessageInputProps {
  themeMode: ThemeMode;
  compact?: boolean;
  onSend: (text: string, side: 'sent' | 'recv', senderName: string, customTime?: string, type?: MessageType, imageUri?: string, voiceDuration?: number) => void;
  onSendImage: (imageUri: string, side: 'sent' | 'recv', senderName: string, caption?: string) => void;
  onSendVoice: (duration: number, side: 'sent' | 'recv', senderName: string) => void;
  onSendCall: (callType: 'voice' | 'video', callStatus: 'missed' | 'answered' | 'outgoing', callDuration: number, side: 'sent' | 'recv') => void;
}

export function MessageInput({ themeMode, compact = false, onSend, onSendImage, onSendVoice, onSendCall }: MessageInputProps) {
  const colors = Colors[themeMode];
  const [input, setInput] = useState('');
  const [senderName, setSenderName] = useState('');
  const [side, setSide] = useState<'sent' | 'recv'>('sent');
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [showVoiceModal, setShowVoiceModal] = useState(false);
  const [showCallModal, setShowCallModal] = useState(false);
  const [voiceDuration, setVoiceDuration] = useState('15');
  const [callType, setCallType] = useState<'voice' | 'video'>('voice');
  const [callStatus, setCallStatus] = useState<'missed' | 'answered' | 'outgoing'>('answered');
  const [callDuration, setCallDuration] = useState('120');
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handleSend = () => {
    if (!input.trim()) return;
    
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 0.8,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();
    
    onSend(input, side, senderName);
    setInput('');
    setSenderName('');
  };

  const toggleSide = () => {
    setSide(prev => prev === 'sent' ? 'recv' : 'sent');
  };

  const handlePickImage = async () => {
    setShowAttachMenu(false);
    
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permissionResult.granted) {
      if (Platform.OS !== 'web') {
        return;
      }
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: false,
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0]) {
      onSendImage(result.assets[0].uri, side, senderName, input.trim() || undefined);
      setInput('');
      setSenderName('');
    }
  };

  const handleSendVoice = () => {
    const duration = parseInt(voiceDuration) || 15;
    onSendVoice(duration, side, senderName);
    setShowVoiceModal(false);
    setVoiceDuration('15');
    setSenderName('');
  };

  const handleSendCall = () => {
    const duration = parseInt(callDuration) || 0;
    onSendCall(callType, callStatus, duration, side);
    setShowCallModal(false);
    setCallDuration('120');
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.surface, borderTopColor: colors.border }]}>
      {side === 'recv' && (
        <View style={styles.senderInputContainer}>
          <TextInput
            style={[styles.senderInput, { backgroundColor: colors.inputBg, color: colors.text }]}
            placeholder="Sender name (optional)"
            placeholderTextColor={colors.textSecondary}
            value={senderName}
            onChangeText={setSenderName}
          />
        </View>
      )}
      <View style={[styles.inputRow, compact && styles.compactInputRow]}>
        <TouchableOpacity 
          style={[
            styles.sideToggle, 
            { backgroundColor: side === 'sent' ? colors.messageSent : colors.messageReceived }
          ]}
          onPress={toggleSide}
        >
          <Ionicons 
            name={side === 'sent' ? 'arrow-forward' : 'arrow-back'} 
            size={20} 
            color={colors.text} 
          />
        </TouchableOpacity>

        <TouchableOpacity 
          style={[styles.attachButton, { backgroundColor: colors.inputBg }]}
          onPress={() => setShowAttachMenu(true)}
        >
          <Ionicons name="attach" size={22} color={colors.primary} />
        </TouchableOpacity>

        <TextInput
          style={[styles.input, compact && styles.compactInput, { backgroundColor: colors.inputBg, color: colors.text }]}
          placeholder="Type a message..."
          placeholderTextColor={colors.textSecondary}
          value={input}
          onChangeText={setInput}
          multiline
          maxLength={500}
        />
        <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
          <TouchableOpacity 
            style={[styles.sendButton, { backgroundColor: colors.primary }]}
            onPress={handleSend}
          >
            <Ionicons name="send" size={20} color="#FFFFFF" />
          </TouchableOpacity>
        </Animated.View>
      </View>

      <Modal visible={showAttachMenu} transparent animationType="fade">
        <TouchableOpacity 
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setShowAttachMenu(false)}
        >
          <View style={[styles.attachMenuContainer, { backgroundColor: colors.surface }]}>
            <Text style={[styles.attachMenuTitle, { color: colors.text }]}>Add to Chat</Text>
            
            <View style={styles.attachOptions}>
              <TouchableOpacity style={styles.attachOption} onPress={handlePickImage}>
                <View style={[styles.attachIcon, { backgroundColor: '#4CAF50' }]}>
                  <Ionicons name="image" size={24} color="#FFFFFF" />
                </View>
                <Text style={[styles.attachLabel, { color: colors.text }]}>Photo</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.attachOption} onPress={() => { setShowAttachMenu(false); setShowVoiceModal(true); }}>
                <View style={[styles.attachIcon, { backgroundColor: '#FF9800' }]}>
                  <Ionicons name="mic" size={24} color="#FFFFFF" />
                </View>
                <Text style={[styles.attachLabel, { color: colors.text }]}>Voice</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.attachOption} onPress={() => { setShowAttachMenu(false); setShowCallModal(true); }}>
                <View style={[styles.attachIcon, { backgroundColor: '#2196F3' }]}>
                  <Ionicons name="call" size={24} color="#FFFFFF" />
                </View>
                <Text style={[styles.attachLabel, { color: colors.text }]}>Call Log</Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity 
              style={[styles.cancelButton, { backgroundColor: colors.border }]}
              onPress={() => setShowAttachMenu(false)}
            >
              <Text style={[styles.cancelText, { color: colors.text }]}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>

      <Modal visible={showVoiceModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.formModal, { backgroundColor: colors.surface }]}>
            <Text style={[styles.formTitle, { color: colors.text }]}>Add Voice Message</Text>
            
            <Text style={[styles.formLabel, { color: colors.textSecondary }]}>Duration (seconds)</Text>
            <TextInput
              style={[styles.formInput, { backgroundColor: colors.inputBg, color: colors.text, borderColor: colors.border }]}
              value={voiceDuration}
              onChangeText={setVoiceDuration}
              keyboardType="numeric"
              placeholder="15"
              placeholderTextColor={colors.textSecondary}
            />

            <View style={styles.formButtons}>
              <TouchableOpacity 
                style={[styles.formButton, { backgroundColor: colors.border }]}
                onPress={() => setShowVoiceModal(false)}
              >
                <Text style={[styles.formButtonText, { color: colors.text }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.formButton, { backgroundColor: colors.primary }]}
                onPress={handleSendVoice}
              >
                <Text style={[styles.formButtonText, { color: '#FFFFFF' }]}>Add</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={showCallModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.formModal, { backgroundColor: colors.surface }]}>
            <Text style={[styles.formTitle, { color: colors.text }]}>Add Call Log</Text>
            
            <Text style={[styles.formLabel, { color: colors.textSecondary }]}>Call Type</Text>
            <View style={styles.optionRow}>
              <TouchableOpacity 
                style={[styles.optionButton, callType === 'voice' && { backgroundColor: colors.primary }]}
                onPress={() => setCallType('voice')}
              >
                <Ionicons name="call" size={18} color={callType === 'voice' ? '#FFFFFF' : colors.text} />
                <Text style={[styles.optionText, { color: callType === 'voice' ? '#FFFFFF' : colors.text }]}>Voice</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.optionButton, callType === 'video' && { backgroundColor: colors.primary }]}
                onPress={() => setCallType('video')}
              >
                <Ionicons name="videocam" size={18} color={callType === 'video' ? '#FFFFFF' : colors.text} />
                <Text style={[styles.optionText, { color: callType === 'video' ? '#FFFFFF' : colors.text }]}>Video</Text>
              </TouchableOpacity>
            </View>

            <Text style={[styles.formLabel, { color: colors.textSecondary }]}>Call Status</Text>
            <View style={styles.optionRow}>
              <TouchableOpacity 
                style={[styles.optionButton, callStatus === 'answered' && { backgroundColor: '#4CAF50' }]}
                onPress={() => setCallStatus('answered')}
              >
                <Text style={[styles.optionText, { color: callStatus === 'answered' ? '#FFFFFF' : colors.text }]}>Answered</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.optionButton, callStatus === 'missed' && { backgroundColor: '#FF3B30' }]}
                onPress={() => setCallStatus('missed')}
              >
                <Text style={[styles.optionText, { color: callStatus === 'missed' ? '#FFFFFF' : colors.text }]}>Missed</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.optionButton, callStatus === 'outgoing' && { backgroundColor: '#2196F3' }]}
                onPress={() => setCallStatus('outgoing')}
              >
                <Text style={[styles.optionText, { color: callStatus === 'outgoing' ? '#FFFFFF' : colors.text }]}>Outgoing</Text>
              </TouchableOpacity>
            </View>

            <Text style={[styles.formLabel, { color: colors.textSecondary }]}>Duration (seconds)</Text>
            <TextInput
              style={[styles.formInput, { backgroundColor: colors.inputBg, color: colors.text, borderColor: colors.border }]}
              value={callDuration}
              onChangeText={setCallDuration}
              keyboardType="numeric"
              placeholder="120"
              placeholderTextColor={colors.textSecondary}
            />

            <View style={styles.formButtons}>
              <TouchableOpacity 
                style={[styles.formButton, { backgroundColor: colors.border }]}
                onPress={() => setShowCallModal(false)}
              >
                <Text style={[styles.formButtonText, { color: colors.text }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.formButton, { backgroundColor: colors.primary }]}
                onPress={handleSendCall}
              >
                <Text style={[styles.formButtonText, { color: '#FFFFFF' }]}>Add</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    borderTopWidth: 1,
  },
  senderInputContainer: {
    marginBottom: Spacing.sm,
  },
  senderInput: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    fontSize: Typography.sizes.base,
  },
  inputRow: {
    flexDirection: 'row',
    minWidth: 0,
    alignItems: 'center',
    gap: Spacing.sm,
  },
  compactInputRow: {
    gap: 4,
  },
  compactInput: {
    paddingHorizontal: 10,
    fontSize: 14,
  },
  sideToggle: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.full,
    alignItems: 'center',
    justifyContent: 'center',
  },
  attachButton: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.full,
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    flex: 1,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    fontSize: Typography.sizes.base,
    maxHeight: 100,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.full,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  attachMenuContainer: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: Spacing.lg,
    paddingBottom: 40,
  },
  attachMenuTitle: {
    fontSize: Typography.sizes.lg,
    fontWeight: Typography.weights.semibold,
    textAlign: 'center',
    marginBottom: Spacing.lg,
  },
  attachOptions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: Spacing.lg,
  },
  attachOption: {
    alignItems: 'center',
    gap: Spacing.sm,
  },
  attachIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
  attachLabel: {
    fontSize: Typography.sizes.sm,
    fontWeight: Typography.weights.medium,
  },
  cancelButton: {
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
  },
  cancelText: {
    fontSize: Typography.sizes.base,
    fontWeight: Typography.weights.medium,
  },
  formModal: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: Spacing.lg,
    paddingBottom: 40,
  },
  formTitle: {
    fontSize: Typography.sizes.lg,
    fontWeight: Typography.weights.semibold,
    textAlign: 'center',
    marginBottom: Spacing.lg,
  },
  formLabel: {
    fontSize: Typography.sizes.sm,
    marginBottom: Spacing.xs,
    marginTop: Spacing.md,
  },
  formInput: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.md,
    fontSize: Typography.sizes.base,
    borderWidth: 1,
  },
  optionRow: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  optionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.xs,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.md,
    backgroundColor: 'rgba(0,0,0,0.05)',
  },
  optionText: {
    fontSize: Typography.sizes.sm,
    fontWeight: Typography.weights.medium,
  },
  formButtons: {
    flexDirection: 'row',
    gap: Spacing.md,
    marginTop: Spacing.lg,
  },
  formButton: {
    flex: 1,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
  },
  formButtonText: {
    fontSize: Typography.sizes.base,
    fontWeight: Typography.weights.semibold,
  },
});
