# Welcome to OnSpace AI

Onspace AI empowers anyone to turn ideas into powerful AI applications in minutes—no coding required. This React Native + Expo project contains a WhatsApp-style chat mockup with portrait-responsive layout, image sharing, voice-message previews, call logs, and optional Firebase persistence.

## Getting Started

```bash
pnpm install
pnpm start
```

Run the platform you need:

```bash
pnpm run android
pnpm run ios
pnpm run web
```

## Firebase setup

Firebase is optional. Without configuration, the app runs with local demo state. To enable realtime Firestore sync:

1. Create a Firebase project at [Firebase Console](https://console.firebase.google.com/).
2. Create a **Web app** in Project settings.
3. Enable **Cloud Firestore** and **Storage**.
4. Copy `.env.example` to `.env`.
5. Paste the Web app config values into `.env`.
6. Restart Expo with `pnpm start --clear`.

The app stores messages in:

```text
chats/demo-chat/messages
```

The Firebase integration lives in:

- `lib/firebase.ts` — Firebase initialization and Storage upload helper
- `services/firebaseChat.ts` — Firestore realtime subscription and CRUD operations
- `hooks/useMessages.ts` — local fallback plus Firebase synchronization

For development only, you can use permissive Firestore rules temporarily. Before production, add Firebase Authentication and restrict reads/writes to authenticated users.

## Deploying with Vercel Environment Variables

The app reads Firebase configuration at build time from `EXPO_PUBLIC_FIREBASE_*` variables, so Firebase values do not need to be committed to GitHub.

1. Import this GitHub repository into Vercel.
2. In **Project Settings → Environment Variables**, add the six variables listed in `.env.example`.
3. Select the environments where each variable should be available: **Production**, **Preview**, and/or **Development**.
4. Deploy or redeploy the project. `vercel.json` runs `pnpm run build:web` and serves the generated `dist` folder.

Vercel variable names must match exactly:

```text
EXPO_PUBLIC_FIREBASE_API_KEY
EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN
EXPO_PUBLIC_FIREBASE_PROJECT_ID
EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET
EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID
EXPO_PUBLIC_FIREBASE_APP_ID
```

After adding or changing variables, a new deployment is required because Expo embeds `EXPO_PUBLIC_*` values during the build. These are Firebase Web client configuration values, not Admin SDK secrets; never add `private_key` or a service-account JSON file to Vercel or GitHub.

## Lint and type checking

```bash
pnpm run lint
pnpm exec tsc --noEmit
```

For the full dependency list, see `package.json`.
