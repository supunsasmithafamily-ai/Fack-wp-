export const Colors = {
  light: {
    primary: '#25D366',
    primaryDark: '#128C7E',
    background: '#E5DDD5',
    backgroundPattern: '#ECE5DD',
    surface: '#FFFFFF',
    messageReceived: '#FFFFFF',
    messageSent: '#DCF8C6',
    text: '#000000',
    textSecondary: '#667781',
    border: '#D1D7DB',
    headerBg: '#FFFFFF',
    headerText: '#000000',
    inputBg: '#FFFFFF',
    timestamp: '#667781',
    checkmark: '#53BDEB',
    checkmarkRead: '#53BDEB',
    dateSeparator: '#8696A0',
    dateSeparatorBg: '#FFFFFF',
    systemMessage: '#E7DECA',
  },
  dark: {
    primary: '#00A884',
    primaryDark: '#008069',
    background: '#0B141A',
    backgroundPattern: '#111B21',
    surface: '#202C33',
    messageReceived: '#202C33',
    messageSent: '#005C4B',
    text: '#E9EDEF',
    textSecondary: '#8696A0',
    border: '#2A3942',
    headerBg: '#FFFFFF',
    headerText: '#000000',
    inputBg: '#2A3942',
    timestamp: '#8696A0',
    checkmark: '#53BDEB',
    checkmarkRead: '#53BDEB',
    dateSeparator: '#8696A0',
    dateSeparatorBg: '#202C33',
    systemMessage: '#182229',
  },
};

export const Typography = {
  sizes: {
    xs: 11,
    sm: 12,
    base: 14,
    lg: 16,
    xl: 18,
    xxl: 20,
  },
  weights: {
    regular: '400' as const,
    medium: '500' as const,
    semibold: '600' as const,
    bold: '700' as const,
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
};

export const BorderRadius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 20,
  full: 999,
};
