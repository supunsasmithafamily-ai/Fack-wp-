import { useState, useCallback } from 'react';
import { Message, MessageType } from '../types';

export function useMessages() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      side: 'recv',
      senderName: 'Customer',
      text: 'Hi! I saw your new products. Looks great!',
      time: '09:01',
      type: 'text',
    },
    {
      id: 2,
      side: 'sent',
      senderName: 'You',
      text: 'Thank you! Would you like to know the price?',
      time: '09:02',
      type: 'text',
    },
  ]);

  const addMessage = useCallback((
    text: string, 
    side: 'sent' | 'recv', 
    senderName: string, 
    customTime?: string,
    type: MessageType = 'text',
    imageUri?: string,
    voiceDuration?: number
  ) => {
    const id = Date.now();
    const time = customTime || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    setMessages(prev => [...prev, {
      id,
      side,
      senderName: senderName.trim() || (side === 'recv' ? 'Customer' : 'You'),
      text: text.trim(),
      time,
      type,
      imageUri,
      voiceDuration,
    }]);
  }, []);

  const addImageMessage = useCallback((
    imageUri: string,
    side: 'sent' | 'recv',
    senderName: string,
    caption?: string,
    customTime?: string
  ) => {
    const id = Date.now();
    const time = customTime || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    setMessages(prev => [...prev, {
      id,
      side,
      senderName: senderName.trim() || (side === 'recv' ? 'Customer' : 'You'),
      text: caption || '',
      time,
      type: 'image',
      imageUri,
    }]);
  }, []);

  const addVoiceMessage = useCallback((
    duration: number,
    side: 'sent' | 'recv',
    senderName: string,
    customTime?: string
  ) => {
    const id = Date.now();
    const time = customTime || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    setMessages(prev => [...prev, {
      id,
      side,
      senderName: senderName.trim() || (side === 'recv' ? 'Customer' : 'You'),
      text: '',
      time,
      type: 'voice',
      voiceDuration: duration,
    }]);
  }, []);

  const addCallMessage = useCallback((
    callType: 'voice' | 'video',
    callStatus: 'missed' | 'answered' | 'outgoing',
    callDuration: number,
    side: 'sent' | 'recv',
    customTime?: string
  ) => {
    const id = Date.now();
    const time = customTime || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    setMessages(prev => [...prev, {
      id,
      side,
      senderName: '',
      text: '',
      time,
      type: 'call',
      callType,
      callStatus,
      callDuration,
    }]);
  }, []);

  const toggleMessageSide = useCallback((id: number) => {
    setMessages(prev => prev.map(msg => 
      msg.id === id ? { ...msg, side: msg.side === 'sent' ? 'recv' : 'sent' } : msg
    ));
  }, []);

  const updateMessageTime = useCallback((id: number, time: string) => {
    setMessages(prev => prev.map(msg => 
      msg.id === id ? { ...msg, time } : msg
    ));
  }, []);

  const updateMessageSender = useCallback((id: number, senderName: string) => {
    setMessages(prev => prev.map(msg => 
      msg.id === id ? { ...msg, senderName } : msg
    ));
  }, []);

  const deleteMessage = useCallback((id: number) => {
    setMessages(prev => prev.filter(msg => msg.id !== id));
  }, []);

  const clearMessages = useCallback(() => {
    setMessages([]);
  }, []);

  return {
    messages,
    addMessage,
    addImageMessage,
    addVoiceMessage,
    addCallMessage,
    toggleMessageSide,
    updateMessageTime,
    updateMessageSender,
    deleteMessage,
    clearMessages,
  };
}
