import { useState, useCallback } from 'react';
import { Profile } from '../types';

export function useProfile() {
  const [profile, setProfile] = useState<Profile>({
    name: 'Your Shop',
    number: '+1 234 567 8900',
    img: null,
  });

  const updateName = useCallback((name: string) => {
    setProfile(prev => ({ ...prev, name }));
  }, []);

  const updateNumber = useCallback((number: string) => {
    setProfile(prev => ({ ...prev, number }));
  }, []);

  const updateImage = useCallback((img: string | null) => {
    setProfile(prev => ({ ...prev, img }));
  }, []);

  return {
    profile,
    updateName,
    updateNumber,
    updateImage,
  };
}
