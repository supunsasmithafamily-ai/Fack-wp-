
import React from 'react';
import { View, StyleSheet, ImageBackground } from 'react-native';
import Svg, { Path, G, Defs, Pattern, Rect } from 'react-native-svg';
import { ThemeMode } from '../types';
import { Colors } from '../constants/theme';

interface BackgroundPatternProps {
  themeMode: ThemeMode;
  customBackground?: string | null;
}

export function BackgroundPattern({ themeMode, customBackground }: BackgroundPatternProps) {
  const colors = Colors[themeMode];
  const patternColor = themeMode === 'light' ? '#D9D9D980' : '#1A1A1A40';

  if (customBackground) {
    return (
      <ImageBackground
        source={{ uri: customBackground }}
        style={StyleSheet.absoluteFill}
        resizeMode="cover"
      />
    );
  }

  return (
    <View style={[StyleSheet.absoluteFill, { backgroundColor: colors.background }]}>
      <Svg width="100%" height="100%" style={StyleSheet.absoluteFill}>
        <Defs>
          <Pattern
            id="whatsappPattern"
            patternUnits="userSpaceOnUse"
            width="200"
            height="200"
          >
            {/* Doodle pattern paths - simplified WhatsApp-style icons */}
            <G opacity="0.08" fill={patternColor} stroke={patternColor} strokeWidth="1.5">
              {/* Heart */}
              <Path d="M40,50 Q40,40 50,40 Q60,40 60,50 Q60,65 50,70 Q40,65 40,50 Z" />
              
              {/* Star */}
              <Path d="M120,45 L123,55 L133,55 L125,61 L128,71 L120,65 L112,71 L115,61 L107,55 L117,55 Z" />
              
              {/* Music note */}
              <Path d="M80,100 L80,120 Q80,125 85,125 Q90,125 90,120 L90,95 L100,92 L100,112 Q100,117 105,117 Q110,117 110,112 L110,88 L80,95 Z" />
              
              {/* Plane */}
              <Path d="M150,100 L140,95 L135,100 L145,102 L140,110 L150,108 L155,115 L157,113 L150,105 L160,103 L165,108 L167,106 L160,98 L165,93 L163,91 L155,95 Z" />
              
              {/* Camera */}
              <Path d="M30,140 L35,135 L45,135 L50,140 L65,140 L65,165 L30,165 Z M47.5,145 Q42.5,145 42.5,152.5 Q42.5,160 47.5,160 Q52.5,160 52.5,152.5 Q52.5,145 47.5,145 Z" />
              
              {/* Smiley */}
              <Path d="M100,145 Q100,135 110,135 Q120,135 120,145 Q120,155 110,155 Q100,155 100,145 Z M107,142 L107,144 M113,142 L113,144 M107,148 Q110,151 113,148" />
              
              {/* Location pin */}
              <Path d="M175,145 Q175,135 180,135 Q185,135 185,145 Q185,155 180,165 Q175,155 175,145 Z M178,143 Q178,140 180,140 Q182,140 182,143 Q182,145 180,145 Q178,145 178,143 Z" />
              
              {/* Gift box */}
              <Path d="M35,30 L60,30 L60,50 L35,50 Z M40,25 Q40,20 47.5,20 Q55,20 55,25 L55,30 L40,30 Z" />
              
              {/* Coffee cup */}
              <Path d="M140,30 L140,50 L165,50 L165,30 Z M165,35 L170,35 Q173,35 173,40 Q173,45 170,45 L165,45" />
              
              {/* Sun */}
              <Path d="M25,85 L20,85 M35,85 L30,85 M27.5,75 L27.5,80 M27.5,90 L27.5,95 M22,78 L24,80 M31,90 L33,92 M22,92 L24,90 M31,80 L33,78 M27.5,85 Q24,85 24,88 Q24,92 27.5,92 Q31,92 31,88 Q31,85 27.5,85 Z" />
            </G>
          </Pattern>
        </Defs>
        <Rect width="100%" height="100%" fill="url(#whatsappPattern)" />
      </Svg>
    </View>
  );
}
