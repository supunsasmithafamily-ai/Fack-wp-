import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Message, ThemeMode } from '../../types';
import { Colors, Typography, Spacing, BorderRadius } from '../../constants/theme';

interface ChatBubbleProps {
  message: Message;
  themeMode: ThemeMode;
  onLongPress: () => void;
}

export function ChatBubble({ message, themeMode, onLongPress }: ChatBubbleProps) {
  const colors = Colors[themeMode];
  const isSent = message.side === 'sent';
  const [isPlaying, setIsPlaying] = useState(false);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const renderCallContent = () => {
    const isVideo = message.callType === 'video';
    const isMissed = message.callStatus === 'missed';
    const isOutgoing = message.callStatus === 'outgoing';
    
    let callText = '';
    let iconName: 'call' | 'videocam' | 'call-outline' | 'videocam-outline' = isVideo ? 'videocam' : 'call';
    let iconColor = colors.primary;
    
    if (isMissed) {
      callText = `Missed ${isVideo ? 'video' : 'voice'} call`;
      iconColor = '#FF3B30';
    } else if (isOutgoing) {
      callText = `Outgoing ${isVideo ? 'video' : 'voice'} call`;
      if (message.callDuration && message.callDuration > 0) {
        callText += ` (${formatDuration(message.callDuration)})`;
      }
    } else {
      callText = `${isVideo ? 'Video' : 'Voice'} call`;
      if (message.callDuration && message.callDuration > 0) {
        callText += ` (${formatDuration(message.callDuration)})`;
      }
    }

    return (
      <View style={styles.callContainer}>
        <View style={[styles.callIconContainer, { backgroundColor: isMissed ? '#FFE5E5' : '#E5F6E5' }]}>
          <Ionicons name={iconName} size={20} color={iconColor} />
          {isOutgoing && (
            <Ionicons 
              name="arrow-up-outline" 
              size={12} 
              color={iconColor} 
              style={styles.callArrow}
            />
          )}
          {!isOutgoing && !isMissed && (
            <Ionicons 
              name="arrow-down-outline" 
              size={12} 
              color={iconColor} 
              style={styles.callArrow}
            />
          )}
        </View>
        <Text style={[styles.callText, { color: isMissed ? '#FF3B30' : colors.text }]}>
          {callText}
        </Text>
      </View>
    );
  };

  const getWaveformHeights = (messageId: number) => {
    const seed = messageId;
    const heights: number[] = [];
    for (let i = 0; i < 25; i++) {
      const hash = Math.sin(seed * (i + 1) * 9999) * 10000;
      heights.push((Math.abs(hash) % 16) + 4);
    }
    return heights;
  };

  const renderVoiceContent = () => {
    const duration = message.voiceDuration || 0;
    const waveformHeights = getWaveformHeights(message.id);
    
    return (
      <View style={styles.voiceContainer}>
        <TouchableOpacity 
          style={[styles.playButton, { backgroundColor: colors.primary }]}
          onPress={() => setIsPlaying(!isPlaying)}
        >
          <Ionicons 
            name={isPlaying ? 'pause' : 'play'} 
            size={18} 
            color="#FFFFFF" 
          />
        </TouchableOpacity>
        <View style={styles.waveformContainer}>
          {waveformHeights.map((height, i) => (
            <View
              key={i}
              style={[
                styles.waveformBar,
                {
                  backgroundColor: colors.primary,
                  height: height,
                  opacity: isPlaying && i < 10 ? 1 : 0.5,
                },
              ]}
            />
          ))}
        </View>
        <Text style={[styles.voiceDuration, { color: colors.textSecondary }]}>
          {formatDuration(duration)}
        </Text>
      </View>
    );
  };

  const renderImageContent = () => {
    return (
      <View style={styles.imageContainer}>
        <Image 
          source={{ uri: message.imageUri }} 
          style={styles.messageImage}
          resizeMode="cover"
        />
        {message.text ? (
          <Text style={[styles.imageCaption, { color: colors.text }]}>
            {message.text}
          </Text>
        ) : null}
      </View>
    );
  };

  const renderTextContent = () => {
    return (
      <Text style={[styles.text, { color: colors.text }]}>
        {message.text}
      </Text>
    );
  };

  const renderContent = () => {
    switch (message.type) {
      case 'call':
        return renderCallContent();
      case 'voice':
        return renderVoiceContent();
      case 'image':
        return renderImageContent();
      default:
        return renderTextContent();
    }
  };

  return (
    <TouchableOpacity
      activeOpacity={0.7}
      onLongPress={onLongPress}
      style={[
        styles.container,
        isSent ? styles.sentContainer : styles.recvContainer,
      ]}
    >
      <View
        style={[
          styles.bubble,
          {
            backgroundColor: isSent ? colors.messageSent : colors.messageReceived,
          },
          isSent ? styles.sentBubble : styles.recvBubble,
          message.type === 'image' && styles.imageBubble,
        ]}
      >
        {!isSent && message.type !== 'call' && (
          <Text style={[styles.senderName, { color: colors.primary }]}>
            {message.senderName}
          </Text>
        )}
        {renderContent()}
        <View style={styles.footer}>
          <Text style={[styles.time, { color: colors.timestamp }]}>
            {message.time}
          </Text>
          {isSent && (
            <View style={styles.checkmarks}>
              <Ionicons name="checkmark-done" size={16} color={colors.checkmarkRead} />
            </View>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    maxWidth: '80%',
  },
  sentContainer: {
    alignSelf: 'flex-end',
  },
  recvContainer: {
    alignSelf: 'flex-start',
  },
  bubble: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.md,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  sentBubble: {
    borderBottomRightRadius: BorderRadius.sm,
  },
  recvBubble: {
    borderBottomLeftRadius: BorderRadius.sm,
  },
  imageBubble: {
    padding: 4,
  },
  senderName: {
    fontSize: Typography.sizes.sm,
    fontWeight: Typography.weights.semibold,
    marginBottom: Spacing.xs,
  },
  text: {
    fontSize: Typography.sizes.base,
    lineHeight: 20,
    marginBottom: 2,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 4,
    marginTop: 2,
  },
  time: {
    fontSize: Typography.sizes.xs,
  },
  checkmarks: {
    marginLeft: 2,
  },
  voiceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    minWidth: 200,
  },
  playButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  waveformContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    flex: 1,
    height: 24,
  },
  waveformBar: {
    width: 3,
    borderRadius: 2,
  },
  voiceDuration: {
    fontSize: Typography.sizes.sm,
    minWidth: 35,
  },
  callContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  callIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  callArrow: {
    position: 'absolute',
    right: 2,
    bottom: 2,
  },
  callText: {
    fontSize: Typography.sizes.base,
    fontWeight: Typography.weights.medium,
  },
  imageContainer: {
    borderRadius: BorderRadius.md - 2,
    overflow: 'hidden',
  },
  messageImage: {
    width: 240,
    height: 180,
    borderRadius: BorderRadius.md - 2,
  },
  imageCaption: {
    fontSize: Typography.sizes.base,
    marginTop: Spacing.sm,
    paddingHorizontal: Spacing.sm,
  },
});
