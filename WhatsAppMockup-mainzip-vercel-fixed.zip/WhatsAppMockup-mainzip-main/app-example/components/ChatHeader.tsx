import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Profile, ThemeMode } from '../types';
import { Colors, Typography, Spacing, BorderRadius } from '../constants/theme';

interface ChatHeaderProps {
  profile: Profile;
  themeMode: ThemeMode;
  onEditProfile: () => void;
  onBack?: () => void;
  onVideoCall?: () => void;
  onVoiceCall?: () => void;
}

export function ChatHeader({ profile, themeMode, onEditProfile, onBack, onVideoCall, onVoiceCall }: ChatHeaderProps) {
  const colors = Colors[themeMode];

  return (
    <View style={[styles.container, { backgroundColor: colors.headerBg }]}>
      {/* Back button */}
      <TouchableOpacity style={styles.backButton} onPress={onBack}>
        <Ionicons name="arrow-back" size={24} color={colors.headerText} />
      </TouchableOpacity>

      {/* Profile section */}
      <TouchableOpacity style={styles.profileSection} onPress={onEditProfile}>
        <View style={styles.avatarContainer}>
          {profile.img ? (
            <Image source={{ uri: profile.img }} style={styles.avatar} />
          ) : (
            <View style={[styles.avatarPlaceholder, { backgroundColor: '#D4C5F9' }]}>
              <Text style={[styles.avatarText, { color: '#6B4FBB' }]}>
                {profile.name.charAt(0).toUpperCase()}
              </Text>
            </View>
          )}
        </View>
        <View style={styles.profileInfo}>
          <Text style={[styles.number, { color: colors.headerText }]} numberOfLines={1}>
            {profile.number}
          </Text>
        </View>
      </TouchableOpacity>

      {/* Action buttons */}
      <View style={styles.actions}>
        <TouchableOpacity style={styles.actionButton} onPress={onVideoCall}>
          <Ionicons name="videocam-outline" size={26} color="#1F2C34" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionButton} onPress={onVoiceCall}>
          <Ionicons name="call-outline" size={24} color="#1F2C34" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionButton} onPress={onEditProfile}>
          <Ionicons name="ellipsis-vertical" size={24} color="#1F2C34" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.sm,
    minHeight: 56,
  },
  backButton: {
    padding: Spacing.sm,
    marginRight: Spacing.xs,
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  avatarContainer: {
    marginRight: Spacing.md,
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.full,
  },
  avatarPlaceholder: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.full,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: Typography.sizes.xl,
    fontWeight: Typography.weights.semibold,
  },
  profileInfo: {
    flex: 1,
  },
  number: {
    fontSize: Typography.sizes.lg,
    fontWeight: Typography.weights.medium,
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  actionButton: {
    padding: Spacing.sm,
  },
});
