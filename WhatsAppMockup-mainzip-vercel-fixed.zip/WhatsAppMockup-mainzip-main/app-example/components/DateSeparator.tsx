import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { ThemeMode } from '../types';
import { Colors, Typography, Spacing, BorderRadius } from '../constants/theme';

interface DateSeparatorProps {
  date: string;
  themeMode: ThemeMode;
}

export function DateSeparator({ date, themeMode }: DateSeparatorProps) {
  const colors = Colors[themeMode];

  return (
    <View style={styles.container}>
      <View style={[styles.badge, { backgroundColor: colors.dateSeparatorBg }]}>
        <Text style={[styles.text, { color: colors.dateSeparator }]}>
          {date}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    paddingVertical: Spacing.md,
  },
  badge: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.md,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  text: {
    fontSize: Typography.sizes.xs,
    fontWeight: Typography.weights.medium,
  },
});
