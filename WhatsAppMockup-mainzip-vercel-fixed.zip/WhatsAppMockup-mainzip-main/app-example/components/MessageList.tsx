import React, { useRef, useEffect } from 'react';
import { FlatList, StyleSheet, Animated, View } from 'react-native';
import { ChatBubble } from './ui/ChatBubble';
import { BackgroundPattern } from './BackgroundPattern';
import { DateSeparator } from './DateSeparator';
import { Message, ThemeMode } from '../types';
import { Colors } from '../constants/theme';

interface MessageListProps {
  messages: Message[];
  themeMode: ThemeMode;
  onMessageLongPress: (message: Message) => void;
  customBackground?: string | null;
}

export function MessageList({ messages, themeMode, onMessageLongPress, customBackground }: MessageListProps) {
  const colors = Colors[themeMode];
  const flatListRef = useRef<FlatList>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (messages.length > 0) {
      // Fade in animation
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start();
      
      // Auto scroll to latest message
      setTimeout(() => {
        flatListRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  }, [messages.length, fadeAnim]);

  return (
    <View style={styles.container}>
      <BackgroundPattern themeMode={themeMode} customBackground={customBackground} />
      <Animated.FlatList
        ref={flatListRef}
        data={messages}
        keyExtractor={item => item.id.toString()}
        ListHeaderComponent={() => (
          <DateSeparator date={new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' })} themeMode={themeMode} />
        )}
        renderItem={({ item, index }) => (
          <Animated.View
            style={{
              opacity: fadeAnim,
              transform: [
                {
                  translateY: fadeAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [20, 0],
                  }),
                },
              ],
            }}
          >
            <ChatBubble
              message={item}
              themeMode={themeMode}
              onLongPress={() => onMessageLongPress(item)}
            />
          </Animated.View>
        )}
        style={styles.list}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  list: {
    flex: 1,
  },
  listContent: {
    paddingVertical: 8,
  },
});
