import React, { useState, useCallback, useRef } from 'react';
import { View, StyleSheet, Platform, Modal, Text, TextInput, TouchableOpacity, KeyboardAvoidingView, StatusBar, Image } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import * as MediaLibrary from 'expo-media-library';
import { captureRef } from 'react-native-view-shot';
import * as Sharing from 'expo-sharing';
import { Ionicons } from '@expo/vector-icons';
import { ChatHeader } from '../components/ChatHeader';
import { MessageList } from '../components/MessageList';
import { MessageInput } from '../components/MessageInput';
import { useMessages } from '../hooks/useMessages';
import { useProfile } from '../hooks/useProfile';
import { Message, ThemeMode } from '../types';
import { Colors, Spacing, Typography, BorderRadius } from '../constants/theme';

export default function WhatsAppMockupScreen() {
  const insets = useSafeAreaInsets();
  const chatViewRef = useRef<View>(null);
  const [themeMode, setThemeMode] = useState<ThemeMode>('light');
  const [profileModalVisible, setProfileModalVisible] = useState(false);
  const [messageEditModalVisible, setMessageEditModalVisible] = useState(false);
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null);
  const [tempName, setTempName] = useState('');
  const [tempNumber, setTempNumber] = useState('');
  const [tempTime, setTempTime] = useState('');
  const [tempSender, setTempSender] = useState('');
  const [customBackground, setCustomBackground] = useState<string | null>(null);
  const [backgroundModalVisible, setBackgroundModalVisible] = useState(false);
  const [callModalVisible, setCallModalVisible] = useState(false);
  const [callType, setCallType] = useState<'voice' | 'video'>('voice');
  const [callStatus, setCallStatus] = useState<'incoming' | 'ongoing' | 'ended'>('incoming');
  const [callDuration, setCallDuration] = useState(0);
  const callTimerRef = useRef<any>(null);
  const [isExporting, setIsExporting] = useState(false);

  const { profile, updateName, updateNumber, updateImage } = useProfile();
  const { messages, addMessage, addImageMessage, addVoiceMessage, addCallMessage, toggleMessageSide, updateMessageTime, updateMessageSender, deleteMessage, clearMessages } = useMessages();

  const colors = Colors[themeMode];

  const handlePickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0]) {
      updateImage(result.assets[0].uri);
    }
  };

  const handlePickBackground = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: false,
      quality: 0.9,
    });

    if (!result.canceled && result.assets[0]) {
      setCustomBackground(result.assets[0].uri);
      setBackgroundModalVisible(false);
    }
  };

  const handleResetBackground = () => {
    setCustomBackground(null);
    setBackgroundModalVisible(false);
  };

  const startCall = (type: 'voice' | 'video') => {
    setCallType(type);
    setCallStatus('incoming');
    setCallDuration(0);
    setCallModalVisible(true);
  };

  const acceptCall = () => {
    setCallStatus('ongoing');
    setCallDuration(0);
    callTimerRef.current = setInterval(() => {
      setCallDuration(prev => prev + 1);
    }, 1000);
  };

  const endCall = () => {
    if (callTimerRef.current) {
      clearInterval(callTimerRef.current);
    }
    const finalDuration = callDuration;
    const currentCallType = callType;
    setCallStatus('ended');
    
    addCallMessage(
      currentCallType,
      finalDuration > 0 ? 'answered' : 'outgoing',
      finalDuration,
      'sent'
    );
    
    setTimeout(() => {
      setCallModalVisible(false);
      setCallDuration(0);
    }, 2000);
  };
  
  const declineCall = () => {
    addCallMessage(callType, 'missed', 0, 'recv');
    setCallModalVisible(false);
    setCallDuration(0);
  };

  const formatCallDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const openProfileModal = () => {
    setTempName(profile.name);
    setTempNumber(profile.number);
    setProfileModalVisible(true);
  };

  const saveProfile = () => {
    updateName(tempName);
    updateNumber(tempNumber);
    setProfileModalVisible(false);
  };

  const handleMessageLongPress = (message: Message) => {
    setSelectedMessage(message);
    setTempTime(message.time);
    setTempSender(message.senderName);
    setMessageEditModalVisible(true);
  };

  const saveMessageEdit = () => {
    if (!selectedMessage) return;
    updateMessageTime(selectedMessage.id, tempTime);
    updateMessageSender(selectedMessage.id, tempSender);
    setMessageEditModalVisible(false);
  };

  const handleToggleSide = () => {
    if (selectedMessage) {
      toggleMessageSide(selectedMessage.id);
      setMessageEditModalVisible(false);
    }
  };

  const handleDeleteMessage = () => {
    if (selectedMessage) {
      deleteMessage(selectedMessage.id);
      setMessageEditModalVisible(false);
    }
  };

  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ visible: true, title, message, onOk });
    } else {
      const Alert = require('react-native').Alert;
      Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
    }
  };

  const handleClearAll = () => {
    showWebAlert('Clear All Messages', 'Are you sure you want to delete all messages?', () => {
      clearMessages();
    });
  };

  const handleExportScreenshot = async () => {
    try {
      if (Platform.OS === 'web') {
        // Web export using canvas
        if (chatViewRef.current) {
          const html2canvas = (window as any).html2canvas;
          if (!html2canvas) {
            showWebAlert('Export', 'Loading export tool... Please click Export again in a moment.');
            // Dynamically load html2canvas
            const script = document.createElement('script');
            script.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js';
            document.head.appendChild(script);
            return;
          }

          const inputArea = document.querySelector('[data-testid="message-input-area"]') as HTMLElement;
          const exportBar = document.querySelector('[data-testid="export-input-bar"]') as HTMLElement;
          
          if (inputArea) inputArea.style.display = 'none';
          if (exportBar) exportBar.style.display = 'flex';
          
          await new Promise(resolve => setTimeout(resolve, 100));

          const element = document.querySelector('[data-testid="chat-container"]') || 
            ((chatViewRef.current as any)._nativeTag 
              ? document.querySelector(`[data-tag="${(chatViewRef.current as any)._nativeTag}"]`)
              : chatViewRef.current);

          if (element) {
            const canvas = await html2canvas(element, {
              backgroundColor: themeMode === 'light' ? '#E5DDD5' : '#0B141A',
              scale: 2,
              logging: false,
            });

            if (inputArea) inputArea.style.display = 'flex';
            if (exportBar) exportBar.style.display = 'none';

            canvas.toBlob((blob: Blob | null) => {
              if (blob) {
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `whatsapp-chat-${new Date().getTime()}.png`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                showWebAlert('Success', 'Screenshot downloaded!');
              }
            }, 'image/png');
          } else {
            if (inputArea) inputArea.style.display = 'flex';
            if (exportBar) exportBar.style.display = 'none';
          }
        }
        return;
      }

      // Mobile export using react-native-view-shot
      const { status } = await MediaLibrary.requestPermissionsAsync();
      if (status !== 'granted') {
        showWebAlert('Permission Required', 'Camera roll permission is needed to save screenshots.');
        return;
      }

      if (chatViewRef.current) {
        const uri = await captureRef(chatViewRef, {
          format: 'png',
          quality: 1,
        });

        await MediaLibrary.saveToLibraryAsync(uri);
        
        if (await Sharing.isAvailableAsync()) {
          await Sharing.shareAsync(uri);
        } else {
          showWebAlert('Success', 'Screenshot saved to gallery!');
        }
      }
    } catch (error) {
      showWebAlert('Error', 'Failed to capture screenshot. Please try again.');
    }
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top, backgroundColor: colors.background }]}>
      <StatusBar 
        barStyle={themeMode === 'light' ? 'light-content' : 'light-content'}
        backgroundColor={colors.headerBg}
      />
      
      {/* Toolbar - NOT included in screenshot */}
      <View style={[styles.toolbar, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <TouchableOpacity 
          style={styles.toolButton}
          onPress={() => setThemeMode(prev => prev === 'light' ? 'dark' : 'light')}
        >
          <Ionicons name={themeMode === 'light' ? 'moon' : 'sunny'} size={20} color={colors.primary} />
          <Text style={[styles.toolText, { color: colors.text }]}>Theme</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.toolButton}
          onPress={handleExportScreenshot}
        >
          <Ionicons name="download-outline" size={20} color={colors.primary} />
          <Text style={[styles.toolText, { color: colors.text }]}>Export</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.toolButton}
          onPress={() => setBackgroundModalVisible(true)}
        >
          <Ionicons name="image-outline" size={20} color={colors.primary} />
          <Text style={[styles.toolText, { color: colors.text }]}>Background</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.toolButton}
          onPress={handleClearAll}
        >
          <Ionicons name="trash-outline" size={20} color={colors.primary} />
          <Text style={[styles.toolText, { color: colors.text }]}>Clear</Text>
        </TouchableOpacity>
      </View>

      {/* Screenshot capture area - includes header, messages, and input */}
      <View ref={chatViewRef} style={styles.chatContainer} collapsable={false} {...{ 'data-testid': 'chat-container' }}>
        <ChatHeader
          profile={profile}
          themeMode={themeMode}
          onEditProfile={openProfileModal}
          onVideoCall={() => startCall('video')}
          onVoiceCall={() => startCall('voice')}
        />
        
        <View style={{ flex: 1 }}>
          <MessageList
            messages={messages}
            themeMode={themeMode}
            onMessageLongPress={handleMessageLongPress}
            customBackground={customBackground}
          />
        </View>

        <View {...{ 'data-testid': 'message-input-area' }}>
          <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
            <MessageInput
              themeMode={themeMode}
              onSend={addMessage}
              onSendImage={addImageMessage}
              onSendVoice={addVoiceMessage}
              onSendCall={addCallMessage}
            />
          </KeyboardAvoidingView>
        </View>
        <View 
          {...{ 'data-testid': 'export-input-bar' }} 
          style={[styles.exportInputBar, { backgroundColor: colors.surface, borderTopColor: colors.border, display: 'none' }]}
        >
          <View style={[styles.exportInputField, { backgroundColor: colors.inputBg }]}>
            <Ionicons name="happy-outline" size={24} color={colors.textSecondary} style={{ marginLeft: 12 }} />
            <Text style={[styles.exportInputPlaceholder, { color: colors.textSecondary }]}>Type a message</Text>
            <Ionicons name="attach" size={24} color={colors.textSecondary} style={{ marginRight: 8 }} />
            <Ionicons name="camera" size={24} color={colors.textSecondary} style={{ marginRight: 12 }} />
          </View>
          <View style={[styles.exportMicButton, { backgroundColor: colors.primary }]}>
            <Ionicons name="mic" size={24} color="#FFFFFF" />
          </View>
        </View>
      </View>

      {/* Profile Edit Modal */}
      <Modal visible={profileModalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.surface }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Edit Profile</Text>
            
            <TouchableOpacity style={styles.imagePickerButton} onPress={handlePickImage}>
              <Ionicons name="camera" size={24} color={colors.primary} />
              <Text style={[styles.imagePickerText, { color: colors.primary }]}>
                {profile.img ? 'Change Photo' : 'Add Photo'}
              </Text>
            </TouchableOpacity>

            <TextInput
              style={[styles.modalInput, { backgroundColor: colors.inputBg, color: colors.text, borderColor: colors.border }]}
              placeholder="Your Name"
              placeholderTextColor={colors.textSecondary}
              value={tempName}
              onChangeText={setTempName}
            />
            <TextInput
              style={[styles.modalInput, { backgroundColor: colors.inputBg, color: colors.text, borderColor: colors.border }]}
              placeholder="Your Number"
              placeholderTextColor={colors.textSecondary}
              value={tempNumber}
              onChangeText={setTempNumber}
            />

            <View style={styles.modalButtons}>
              <TouchableOpacity 
                style={[styles.modalButton, { backgroundColor: colors.border }]}
                onPress={() => setProfileModalVisible(false)}
              >
                <Text style={[styles.modalButtonText, { color: colors.text }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.modalButton, { backgroundColor: colors.primary }]}
                onPress={saveProfile}
              >
                <Text style={[styles.modalButtonText, { color: '#FFFFFF' }]}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Message Edit Modal */}
      <Modal visible={messageEditModalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.surface }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Edit Message</Text>
            
            <TextInput
              style={[styles.modalInput, { backgroundColor: colors.inputBg, color: colors.text, borderColor: colors.border }]}
              placeholder="Sender Name"
              placeholderTextColor={colors.textSecondary}
              value={tempSender}
              onChangeText={setTempSender}
            />
            <TextInput
              style={[styles.modalInput, { backgroundColor: colors.inputBg, color: colors.text, borderColor: colors.border }]}
              placeholder="Time (e.g., 09:01)"
              placeholderTextColor={colors.textSecondary}
              value={tempTime}
              onChangeText={setTempTime}
            />

            <View style={styles.actionButtons}>
              <TouchableOpacity 
                style={[styles.actionButton, { backgroundColor: colors.inputBg }]}
                onPress={handleToggleSide}
              >
                <Ionicons name="swap-horizontal" size={20} color={colors.text} />
                <Text style={[styles.actionButtonText, { color: colors.text }]}>Toggle Side</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.actionButton, { backgroundColor: '#FF3B30' }]}
                onPress={handleDeleteMessage}
              >
                <Ionicons name="trash" size={20} color="#FFFFFF" />
                <Text style={[styles.actionButtonText, { color: '#FFFFFF' }]}>Delete</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.modalButtons}>
              <TouchableOpacity 
                style={[styles.modalButton, { backgroundColor: colors.border }]}
                onPress={() => setMessageEditModalVisible(false)}
              >
                <Text style={[styles.modalButtonText, { color: colors.text }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.modalButton, { backgroundColor: colors.primary }]}
                onPress={saveMessageEdit}
              >
                <Text style={[styles.modalButtonText, { color: '#FFFFFF' }]}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Background Selection Modal */}
      <Modal visible={backgroundModalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.surface }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Background Theme</Text>
            
            <TouchableOpacity 
              style={[styles.backgroundOption, { backgroundColor: colors.inputBg, borderColor: colors.border }]}
              onPress={handlePickBackground}
            >
              <Ionicons name="image" size={24} color={colors.primary} />
              <View style={styles.optionText}>
                <Text style={[styles.optionTitle, { color: colors.text }]}>Upload Custom Background</Text>
                <Text style={[styles.optionDesc, { color: colors.textSecondary }]}>Choose from gallery</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity 
              style={[styles.backgroundOption, { backgroundColor: colors.inputBg, borderColor: colors.border }]}
              onPress={handleResetBackground}
            >
              <Ionicons name="refresh" size={24} color={colors.primary} />
              <View style={styles.optionText}>
                <Text style={[styles.optionTitle, { color: colors.text }]}>Default Pattern</Text>
                <Text style={[styles.optionDesc, { color: colors.textSecondary }]}>WhatsApp doodle background</Text>
              </View>
            </TouchableOpacity>

            {customBackground && (
              <View style={[styles.previewContainer, { borderColor: colors.border }]}>
                <Text style={[styles.previewLabel, { color: colors.textSecondary }]}>Current Background:</Text>
                <Image source={{ uri: customBackground }} style={styles.backgroundPreview} />
              </View>
            )}

            <TouchableOpacity 
              style={[styles.modalButton, { backgroundColor: colors.border, marginTop: Spacing.md }]}
              onPress={() => setBackgroundModalVisible(false)}
            >
              <Text style={[styles.modalButtonText, { color: colors.text }]}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Call Modal */}
      <Modal visible={callModalVisible} transparent animationType="fade">
        <View style={styles.callOverlay}>
          <View style={styles.callContainer}>
            {callStatus === 'incoming' && (
              <>
                <View style={styles.callAvatarContainer}>
                  {profile.img ? (
                    <Image source={{ uri: profile.img }} style={styles.callAvatar} />
                  ) : (
                    <View style={[styles.callAvatarPlaceholder, { backgroundColor: '#D4C5F9' }]}>
                      <Text style={[styles.callAvatarText, { color: '#6B4FBB' }]}>
                        {profile.name.charAt(0).toUpperCase()}
                      </Text>
                    </View>
                  )}
                </View>
                <Text style={styles.callName}>{profile.number}</Text>
                <Text style={styles.callStatus}>WhatsApp {callType === 'video' ? 'Video' : 'Voice'} Call</Text>
                <View style={styles.callButtons}>
                  <TouchableOpacity 
                    style={[styles.callButton, { backgroundColor: '#FF3B30' }]}
                    onPress={declineCall}
                  >
                    <Ionicons name="close" size={32} color="#FFFFFF" />
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={[styles.callButton, { backgroundColor: '#25D366' }]}
                    onPress={acceptCall}
                  >
                    <Ionicons name="call" size={32} color="#FFFFFF" />
                  </TouchableOpacity>
                </View>
              </>
            )}
            {callStatus === 'ongoing' && (
              <>
                <View style={styles.callAvatarContainer}>
                  {profile.img ? (
                    <Image source={{ uri: profile.img }} style={styles.callAvatar} />
                  ) : (
                    <View style={[styles.callAvatarPlaceholder, { backgroundColor: '#D4C5F9' }]}>
                      <Text style={[styles.callAvatarText, { color: '#6B4FBB' }]}>
                        {profile.name.charAt(0).toUpperCase()}
                      </Text>
                    </View>
                  )}
                </View>
                <Text style={styles.callName}>{profile.number}</Text>
                <Text style={styles.callDuration}>{formatCallDuration(callDuration)}</Text>
                <TouchableOpacity 
                  style={[styles.endCallButton, { backgroundColor: '#FF3B30' }]}
                  onPress={endCall}
                >
                  <Ionicons name="call" size={32} color="#FFFFFF" />
                </TouchableOpacity>
              </>
            )}
            {callStatus === 'ended' && (
              <>
                <View style={styles.callAvatarContainer}>
                  {profile.img ? (
                    <Image source={{ uri: profile.img }} style={styles.callAvatar} />
                  ) : (
                    <View style={[styles.callAvatarPlaceholder, { backgroundColor: '#D4C5F9' }]}>
                      <Text style={[styles.callAvatarText, { color: '#6B4FBB' }]}>
                        {profile.name.charAt(0).toUpperCase()}
                      </Text>
                    </View>
                  )}
                </View>
                <Text style={styles.callName}>{profile.number}</Text>
                <Text style={styles.callStatus}>Call Ended</Text>
                <Text style={styles.callDuration}>{formatCallDuration(callDuration)}</Text>
              </>
            )}
          </View>
        </View>
      </Modal>

      {/* Web Alert Modal */}
      {Platform.OS === 'web' && (
        <Modal visible={alertConfig.visible} transparent animationType="fade">
          <View style={styles.alertOverlay}>
            <View style={[styles.alertBox, { backgroundColor: colors.surface }]}>
              <Text style={[styles.alertTitle, { color: colors.text }]}>{alertConfig.title}</Text>
              <Text style={[styles.alertMessage, { color: colors.textSecondary }]}>{alertConfig.message}</Text>
              <TouchableOpacity 
                style={[styles.alertButton, { backgroundColor: colors.primary }]}
                onPress={() => {
                  alertConfig.onOk?.();
                  setAlertConfig(prev => ({ ...prev, visible: false }));
                }}
              >
                <Text style={styles.alertButtonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  toolbar: {
    flexDirection: 'row',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    gap: Spacing.md,
    borderBottomWidth: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  chatContainer: {
    flex: 1,
  },
  toolButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
  },
  toolText: {
    fontSize: Typography.sizes.sm,
    fontWeight: Typography.weights.medium,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '85%',
    maxWidth: 400,
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
  },
  modalTitle: {
    fontSize: Typography.sizes.xl,
    fontWeight: Typography.weights.bold,
    marginBottom: Spacing.lg,
  },
  imagePickerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.md,
    marginBottom: Spacing.lg,
  },
  imagePickerText: {
    fontSize: Typography.sizes.base,
    fontWeight: Typography.weights.medium,
  },
  modalInput: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.md,
    fontSize: Typography.sizes.base,
    marginBottom: Spacing.md,
    borderWidth: 1,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: Spacing.sm,
    marginBottom: Spacing.lg,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.xs,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.md,
  },
  actionButtonText: {
    fontSize: Typography.sizes.sm,
    fontWeight: Typography.weights.medium,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  modalButton: {
    flex: 1,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
  },
  modalButtonText: {
    fontSize: Typography.sizes.base,
    fontWeight: Typography.weights.semibold,
  },
  alertOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertBox: {
    width: 280,
    padding: Spacing.xl,
    borderRadius: BorderRadius.md,
  },
  alertTitle: {
    fontSize: Typography.sizes.lg,
    fontWeight: Typography.weights.bold,
    marginBottom: Spacing.sm,
  },
  alertMessage: {
    fontSize: Typography.sizes.base,
    marginBottom: Spacing.lg,
  },
  alertButton: {
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.sm,
    alignItems: 'center',
  },
  alertButtonText: {
    color: '#FFFFFF',
    fontWeight: Typography.weights.bold,
    fontSize: Typography.sizes.base,
  },
  backgroundOption: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.lg,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.md,
    borderWidth: 1,
  },
  optionText: {
    flex: 1,
  },
  optionTitle: {
    fontSize: Typography.sizes.base,
    fontWeight: Typography.weights.semibold,
    marginBottom: Spacing.xs,
  },
  optionDesc: {
    fontSize: Typography.sizes.sm,
  },
  previewContainer: {
    marginTop: Spacing.md,
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
  },
  previewLabel: {
    fontSize: Typography.sizes.sm,
    marginBottom: Spacing.sm,
  },
  backgroundPreview: {
    width: '100%',
    height: 150,
    borderRadius: BorderRadius.md,
    resizeMode: 'cover',
  },
  callOverlay: {
    flex: 1,
    backgroundColor: '#0B141A',
    justifyContent: 'center',
    alignItems: 'center',
  },
  callContainer: {
    alignItems: 'center',
    padding: Spacing.xxl,
  },
  callAvatarContainer: {
    marginBottom: Spacing.xxl,
  },
  callAvatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
  },
  callAvatarPlaceholder: {
    width: 120,
    height: 120,
    borderRadius: 60,
    alignItems: 'center',
    justifyContent: 'center',
  },
  callAvatarText: {
    fontSize: 48,
    fontWeight: Typography.weights.bold,
  },
  callName: {
    fontSize: Typography.sizes.xxl,
    fontWeight: Typography.weights.semibold,
    color: '#FFFFFF',
    marginBottom: Spacing.sm,
  },
  callStatus: {
    fontSize: Typography.sizes.base,
    color: '#8696A0',
    marginBottom: Spacing.xxl,
  },
  callDuration: {
    fontSize: Typography.sizes.xl,
    color: '#FFFFFF',
    marginBottom: Spacing.xxl,
  },
  callButtons: {
    flexDirection: 'row',
    gap: 60,
    marginTop: Spacing.xxl,
  },
  callButton: {
    width: 70,
    height: 70,
    borderRadius: 35,
    alignItems: 'center',
    justifyContent: 'center',
  },
  endCallButton: {
    width: 70,
    height: 70,
    borderRadius: 35,
    alignItems: 'center',
    justifyContent: 'center',
    transform: [{ rotate: '135deg' }],
  },
  exportInputBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.sm,
    borderTopWidth: 1,
    gap: Spacing.sm,
  },
  exportInputField: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    height: 48,
    borderRadius: 24,
  },
  exportInputPlaceholder: {
    flex: 1,
    fontSize: Typography.sizes.base,
    marginLeft: Spacing.sm,
  },
  exportMicButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
