# WhatsApp Mockup Application

## Overview
This is a WhatsApp chat mockup application built with Expo (React Native for Web). It allows users to create fake WhatsApp chat screenshots with customizable messages, profiles, and backgrounds.

## Features
- Create and send text messages
- Send photo messages with optional captions
- Add voice message mockups with customizable duration
- Add call logs (voice/video calls with missed/answered/outgoing status)
- Toggle between light and dark themes
- Edit sender names and message times
- Change chat background
- Export chat as screenshot
- Voice and video call simulation with call log creation
- Profile editing with custom images

## Tech Stack
- Expo SDK 53
- React Native Web
- TypeScript
- Expo Router

## Running the Project
The application runs on port 5000 using Expo web. The workflow is configured to start automatically.

## Project Structure
- `/app` - Main application screens and routing
- `/components` - Reusable UI components (ChatHeader, MessageList, MessageInput, ChatBubble, etc.)
- `/hooks` - Custom React hooks (useMessages, useProfile)
- `/constants` - Theme and color definitions
- `/types` - TypeScript type definitions
- `/assets` - Images and fonts

## Message Types
- `text` - Regular text messages
- `image` - Photo messages with optional captions
- `voice` - Voice message mockups with waveform visualization
- `call` - Call log entries (voice/video, missed/answered/outgoing)

## How to Use
1. Use the arrow button to toggle between sent/received messages
2. Click the attach button (paperclip) to add photos, voice messages, or call logs
3. Type a message and click send
4. Long press on any message to edit time, sender name, toggle side, or delete
5. Use the header icons to simulate voice/video calls
6. Use the toolbar to change theme, export screenshot, change background, or clear messages

## Recent Changes
- January 22, 2026: Added photo, voice message, and call log support
- January 22, 2026: Initial setup and deployment
