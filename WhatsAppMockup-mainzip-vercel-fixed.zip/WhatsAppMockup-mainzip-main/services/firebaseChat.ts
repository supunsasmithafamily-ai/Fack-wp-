import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  type Unsubscribe,
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Message } from '../types';

const CHAT_ID = 'demo-chat';
const messagesCollection = () => {
  if (!db) throw new Error('Firestore is not configured.');
  return collection(db, 'chats', CHAT_ID, 'messages');
};

const messageDocument = (id: number) => doc(messagesCollection(), String(id));

function toFirestoreMessage(message: Message) {
  return {
    ...message,
    updatedAt: serverTimestamp(),
  };
}

export function subscribeToMessages(
  onMessages: (messages: Message[]) => void,
  onError: (error: Error) => void,
): Unsubscribe | null {
  if (!db) return null;

  const messagesQuery = query(messagesCollection(), orderBy('id', 'asc'));
  return onSnapshot(
    messagesQuery,
    snapshot => {
      onMessages(snapshot.docs.map(item => item.data() as Message));
    },
    error => onError(error),
  );
}

export async function saveMessage(message: Message) {
  if (!db) return;
  await setDoc(messageDocument(message.id), toFirestoreMessage(message), { merge: true });
}

export async function seedMessages(messages: Message[]) {
  if (!db) return;
  await Promise.all(messages.map(message => saveMessage(message)));
}

export async function updateMessageRemote(id: number, values: Partial<Message>) {
  if (!db) return;
  await updateDoc(messageDocument(id), { ...values, updatedAt: serverTimestamp() });
}

export async function deleteMessageRemote(id: number) {
  if (!db) return;
  await deleteDoc(messageDocument(id));
}

export async function clearMessagesRemote(messages: Message[]) {
  await Promise.all(messages.map(message => deleteMessageRemote(message.id)));
}

export async function addMessageRemote(message: Message) {
  if (!db) return;
  await setDoc(messageDocument(message.id), {
    ...toFirestoreMessage(message),
    createdAt: serverTimestamp(),
  });
}
